class ActivityUserRelation < ActiveRecord::Base
end
